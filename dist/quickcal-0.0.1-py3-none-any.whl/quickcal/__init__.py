class QuickCal:
    def __init__(self, num_1, num_2):
        self.num_1 = num_1
        self.num_2 = num_2

    def addition(self):
        add = self.num_1 + self.num_2
        return add

    def substraction(self):
        sub = self.num_1 - self.num_2
        return sub   
    def multiplication(self):
        mul = self.num_1 * self.num_2
        return mul  

    def division(self):
        div = self.num_1 / self.num_2
        return div        
