# QUICK CALCULATION

This library will help to calculate numbers quickly.

# How to install?
'''
pip install quickcal
'''

# initializing package
'''
from quickcal import QuickCal

num_1 = 16
num_2 = 8

cal = QuickCal(num_1, num_2)
'''

# for addition
'''
cal.addition()
'''

# for substraction
'''
cal.substraction()
'''

# for multiplication
'''
cal.multiplication()
'''

# for division
'''
cal.division()
'''
